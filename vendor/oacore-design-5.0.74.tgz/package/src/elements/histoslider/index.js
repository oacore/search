export default from './histoslider'
