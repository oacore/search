export default from './switch'
