```jsx
<LoadingBar isLoading/>
```
